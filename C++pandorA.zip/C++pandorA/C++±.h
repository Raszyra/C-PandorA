#ifndef CPP_N_H
#define CPP_N_H

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cmath>

#define si if
#define sino else
#define hacer do
#define mientras while
#define para for
#define cambiar switch
#define caso case
#define predeterminado default
#define romper break
#define continuar continue

#define funcion void
#define devolver return
#define entero int
#define flotante float
#define caracter char
#define cadena std::string
#define booleano bool
#define verdadero true
#define falso false
#define constante const
#define estatico static
#define externo extern

#define definir struct
#define clase class
#define publico public
#define privado private
#define protegido protected

#define nuevo new
#define borrar delete

#define mostrar std::cout
#define ingresar std::cin
#define salto std::endl

#define principal main

// ======= Funciones adicionales =======

// Vectores (std::vector)
#define vektor std::vector
#define agregar push_back
#define quitar pop_back
#define tamaño size

// Funciones matemáticas (cmath)
#define raiz sqrt
#define potencia pow
#define seno sin
#define coseno cos
#define tangente tan
#define absoluto abs

// Manejo de archivos (std::fstream)
#define archivo std::fstream
#define leerarchivo std::ifstream
#define escribirarchivo std::ofstream
#define abrir open
#define cerrar close
#define leer read
#define escribir write
#define bueno good
#define fin_de_archivo eof

#endif // CPP_N_H