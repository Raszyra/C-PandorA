#ifndef ROMAJI_PP_H
#define ROMAJI_PP_H

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cmath>

#define moshi if
#define sasenka else
#define suru do
#define mazu while
#define tame for
#define koushin switch
#define baai case
#define dainou default
#define yaburi break
#define tsuzuku continue

#define kinou void
#define kaeriru return
#define intouchi int
#define shousuu float
#define moji char
#define mojikigou std::string
#define bourei bool
#define hontou true
#define uso false
#define teijiru const
#define seiji static
#define taitei extern

#define teigi struct
#define kurasu class
#define koukyou public
#define naikou private
#define hogo protected

#define atarashii new
#define sakujo delete

#define dasu std::cout
#define toru std::cin
#define kaigyou std::endl

#define shuyou main

// ======= Tsuuika Kinou =======

// Vekutaa (std::vector)
#define vekutaa std::vector
#define kuwaeru push_back
#define sakujo pop_back
#define saizu size

// Suuji kinou (cmath)
#define sukuu root
#define joubu pow
#define shin sin
#define kosu cos
#define tanjin tan
#define zannen abs

// Fairu handling (std::fstream)
#define fairu std::fstream
#define yomifairu std::ifstream
#define kaku_fairu std::ofstream
#define hiraku open
#define tojikomeru close
#define yomu read
#define kaku write
#define yoi good
#define owari reached eof

#endif // ROMAJI_PP_H