#include "C++PandorA.h"

funktion prln(konstant mojikigou& text)
{
    mostrar << salto << text << kaigyou;
}


int main(int argc, char *argv[])
{
	prln("Hola, boku no sekai!");
	
	devolver 0;
}