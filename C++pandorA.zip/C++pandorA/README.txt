/*
+--------------------------------------------------------------+
C++PandorA

>>> This software is provided as-is
>> Open source and liability-free.
> Licensed under GNU GPL v3

Enjoy responsibly!

+--------------------------------------------------------------+
    This is a collection of multilingual
    command keywords for C++std17.
    
    To add this library to your project,
    simply #include "C++PandorA\C++PandorA.h"
    (using the relative filepath on
    your machine.)
    
    Languages: German, French, Spanish,
    and Japanese (Romaji);
    
    Keywords re-#defined:

if

else

do

while

for

switch

case

default

break

continue

void

return

int

float

char

std::string

bool

true

false

struct

class

public

private

protected

new

delete

std::cout

std::cin

std::endl

main

const

static

extern

+--------------------------------------------------------+

/*