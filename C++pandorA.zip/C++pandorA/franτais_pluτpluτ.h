#ifndef FRANCAIS_PP_H
#define FRANCAIS_PP_H

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cmath>

#define si if
#define sinon else
#define faire do
#define tantque while
#define pour for
#define changer switch
#define cas case
#define défaut default
#define casser break
#define continuer continue

#define fonction void
#define retourner return
#define entier int
#define flottant float
#define caractere char
#define chaine std::string
#define booléen bool
#define vrai true
#define faux false

#define struct struct
#define classe class
#define public public
#define privé private
#define protégé protected

#define nouveau new
#define supprimer delete

#define afficher std::cout
#define saisir std::cin
#define retour std::endl

#define principal main

// ======= Fonctionnalités supplémentaires =======

// Vecteurs (std::vector)
#define vecteur std::vector
#define ajouter push_back
#define retirer pop_back
#define taille size

// Fonctions mathématiques (cmath)
#define racine sqrt
#define puissance pow
#define sinus sin
#define cosinus cos
#define tangente tan
#define absolu abs

// Gestion des fichiers (std::fstream)
#define fichier std::fstream
#define fichierLecture std::ifstream
#define fichierÉcriture std::ofstream
#define ouvrir open
#define fermer close
#define lire read
#define écrire write
#define bon good
#define finDeFichier eof

// ======= Mots-clés supplémentaires =======

// const
#define constant const
// static
#define statique static
// extern
#define externe extern

#endif // FRANCAIS_PP_H