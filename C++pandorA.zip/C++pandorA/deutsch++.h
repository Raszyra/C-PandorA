#ifndef DEUTSCH_PP_H
#define DEUTSCH_PP_H

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cmath>

#define wenn if
#define sonst else
#define tun do
#define während while
#define für for
#define wechseln switch
#define fall case
#define standard default
#define brechen break
#define weiter continue

#define funktion void
#define zurückgeben return
#define ganz int
#define fliesskomma float
#define zeichen char
#define zeichenkette std::string
#define boolesch bool
#define wahr true
#define falsch false
#define konstant const
#define statisch static

#define struktur struct
#define klasse class
#define öffentlich public
#define privat private
#define geschützt protected

#define neu new
#define löschen delete

#define ausgeben std::cout
#define eingeben std::cin
#define zeilenumbruch std::endl

#define haupt main

// ======= Zusätzliche Funktionen =======

// Vektoren (std::vector)
#define vektor std::vector
#define hinzufügen push_back
#define entfernen pop_back
#define grösse size

// Mathematische Funktionen (cmath)
#define wurzel sqrt
#define potenz pow
#define sinus sin
#define kosinus cos
#define tangens tan
#define absolut abs

// Datei-Handling (std::fstream)
#define datei std::fstream
#define lesedatei std::ifstream
#define schreibdatei std::ofstream
#define öffnen open
#define schliessen close
#define lesen read
#define schreiben write
#define gut good
#define ende erreicht eof

#endif // DEUTSCH_PP_H