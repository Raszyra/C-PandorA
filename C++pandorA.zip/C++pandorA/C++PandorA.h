#ifndef CPPANDORA_H
#define CPPANDORA_H

#include "C++ñ.h"
#include "romaji++.h"
#include "deutsch++.h"
#include "français_pluçpluç.h"

#endif